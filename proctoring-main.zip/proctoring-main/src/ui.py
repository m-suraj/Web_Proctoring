from tkinter import *
from tkinter import ttk
root = Tk()
frm = ttk.Frame(root, padding=10)


root.mainloop()